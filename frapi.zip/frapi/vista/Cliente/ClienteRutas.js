const express = require('express');
const CRutas = require('../../controlador/Cliente/ClienteControlador');
const router = express.Router();

router.post('/crear', CRutas.crearCliente);
module.exports = router; 